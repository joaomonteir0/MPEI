clear all;

N = 1e5 % repetições
p = 1/27 % probabilidade

sucesso = rand(1,N) < p;

% tá mal nao era para fazer no matlab