lambda = 15;
k=0;
pka = ((lambda^k)/factorial(k))*exp(-lambda);

pka
