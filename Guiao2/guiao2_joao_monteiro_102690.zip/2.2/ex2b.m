% o espaço de amostragem é constituído por 3 notas
% xi = {5, 50, 100}
% px(xi) = [0.9 0.09 0.01]