%a

%b

%c