%{
90 notas de 5
9 notas de 50
1 nota de 100

O espaço de amostragem é constituído por 100 notas (100 elementos)

PROBABILIDADE - ACONTECIMENTOS ELEMENTARES:
>>> p(5) -> probabilidade de sair nota de 5 euros
casos favoráveis : 90
casos totais : 100
p(5) = 90/100 = 0.9 = 90%

>>> p(50) -> probabilidade de sair nota de 50 euros
casos favoráveis: 9
casos totais: 100
p(50) = 9/100 = 0.09 = 9%

>>> p(100) -> probabilidade de sair nota de 100 euros
casos favoráveis: 1
casos totais: 100
p(100) = 1/100 = 0.01 = 1%

%}